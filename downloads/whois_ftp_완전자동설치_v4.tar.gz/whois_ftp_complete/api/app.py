#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
후이즈 호스팅 전용 이도출판 Flask 백엔드
설정 없이 바로 작동하는 버전
"""

import os
import sys
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta

# PyMySQL을 MySQLdb로 사용
try:
    import pymysql
    pymysql.install_as_MySQLdb()
except:
    pass

# Flask 앱 생성
app = Flask(__name__)

# 후이즈 호스팅 자동 설정
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://idopress_user:idopress123@localhost/idopress'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'idopress-secret-key-2024'
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)

# CORS 허용
CORS(app, origins=['*'])

# 데이터베이스 및 JWT 초기화
db = SQLAlchemy(app)
jwt = JWTManager(app)

# 사용자 모델
class User(db.Model):
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'is_admin': self.is_admin,
            'is_active': self.is_active
        }

# 도서 모델
class Book(db.Model):
    __tablename__ = 'books'
    
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    title_original = db.Column(db.String(200))
    author = db.Column(db.String(100), nullable=False)
    era = db.Column(db.String(50))
    genre = db.Column(db.String(50))
    description = db.Column(db.Text)
    content = db.Column(db.Text)
    content_modern = db.Column(db.Text)
    publication_date = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_public = db.Column(db.Boolean, default=True)
    view_count = db.Column(db.Integer, default=0)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'title_original': self.title_original,
            'author': self.author,
            'era': self.era,
            'genre': self.genre,
            'description': self.description,
            'publication_date': self.publication_date,
            'view_count': self.view_count,
            'has_modern_translation': bool(self.content_modern),
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

# API 엔드포인트

@app.route('/')
def home():
    return """
    <h1>🎉 이도출판 디지털 장서각 API</h1>
    <p>✅ 백엔드 서버가 정상 작동중입니다!</p>
    <ul>
        <li><a href="/api/health">상태 확인</a></li>
        <li><a href="/api/books">도서 목록</a></li>
        <li><a href="/api/books/genres">장르 목록</a></li>
    </ul>
    """

@app.route('/api/health')
def health_check():
    """서버 상태 확인"""
    return jsonify({
        'status': 'healthy',
        'message': '이도출판 디지털 장서각 API 서버 정상 작동',
        'version': 'v4.0-whois',
        'timestamp': datetime.utcnow().isoformat()
    })

@app.route('/api/books', methods=['GET'])
def get_books():
    """도서 목록 조회"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = min(request.args.get('per_page', 20, type=int), 100)
        search = request.args.get('search', '')
        genre = request.args.get('genre', '')
        
        # 기본 쿼리
        query = Book.query.filter_by(is_public=True)
        
        # 검색 필터
        if search:
            search_pattern = f'%{search}%'
            query = query.filter(
                db.or_(
                    Book.title.like(search_pattern),
                    Book.author.like(search_pattern),
                    Book.description.like(search_pattern)
                )
            )
        
        # 장르 필터
        if genre and genre != 'all':
            query = query.filter(Book.genre == genre)
        
        # 정렬 및 페이지네이션
        query = query.order_by(Book.view_count.desc())
        total = query.count()
        
        books = query.offset((page - 1) * per_page).limit(per_page).all()
        
        return jsonify({
            'books': [book.to_dict() for book in books],
            'total': total,
            'pages': (total + per_page - 1) // per_page,
            'current_page': page,
            'per_page': per_page
        })
    
    except Exception as e:
        return jsonify({'error': f'도서 목록 조회 실패: {str(e)}'}), 500

@app.route('/api/books/genres', methods=['GET'])
def get_genres():
    """장르 목록 조회"""
    try:
        genres_query = db.session.query(Book.genre).filter(
            Book.genre.isnot(None),
            Book.is_public == True
        ).distinct()
        
        genre_list = [genre[0] for genre in genres_query if genre[0]]
        
        return jsonify({
            'genres': sorted(genre_list)
        })
    
    except Exception as e:
        return jsonify({'error': f'장르 목록 조회 실패: {str(e)}'}), 500

@app.route('/api/books/<int:book_id>', methods=['GET'])
def get_book(book_id):
    """특정 도서 상세 조회"""
    try:
        book = Book.query.get(book_id)
        
        if not book or not book.is_public:
            return jsonify({'error': '도서를 찾을 수 없습니다'}), 404
        
        # 조회수 증가
        book.view_count += 1
        db.session.commit()
        
        # 전체 내용 포함
        book_data = book.to_dict()
        book_data.update({
            'content': book.content,
            'content_modern': book.content_modern
        })
        
        return jsonify({'book': book_data})
    
    except Exception as e:
        return jsonify({'error': f'도서 조회 실패: {str(e)}'}), 500

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    """관리자 로그인"""
    try:
        data = request.get_json()
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({'error': '사용자명과 비밀번호를 입력하세요'}), 400
        
        user = User.query.filter_by(username=username, is_admin=True).first()
        
        if not user or not user.check_password(password):
            return jsonify({'error': '잘못된 관리자 정보입니다'}), 401
        
        access_token = create_access_token(identity=str(user.id))
        
        return jsonify({
            'message': '관리자 로그인 성공',
            'access_token': access_token,
            'user': user.to_dict()
        })
    
    except Exception as e:
        return jsonify({'error': f'로그인 실패: {str(e)}'}), 500

# 에러 핸들러
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': '요청한 페이지를 찾을 수 없습니다'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': '서버 내부 오류가 발생했습니다'}), 500

# cPanel Python App에서 사용할 application 객체
application = app

# 로컬 테스트용
if __name__ == '__main__':
    with app.app_context():
        try:
            db.create_all()
        except:
            pass
    app.run(debug=False, host='0.0.0.0', port=5000)